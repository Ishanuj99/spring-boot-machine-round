package com.test.machine_coding.DTO;

import lombok.Data;

@Data
public class UpdateStockDTO {
    String id;
    int stock;
}

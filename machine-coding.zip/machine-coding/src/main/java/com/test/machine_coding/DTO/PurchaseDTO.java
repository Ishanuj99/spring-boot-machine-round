package com.test.machine_coding.DTO;

import lombok.Data;

@Data
public class PurchaseDTO {
    String dealId;
    String userId;
}
